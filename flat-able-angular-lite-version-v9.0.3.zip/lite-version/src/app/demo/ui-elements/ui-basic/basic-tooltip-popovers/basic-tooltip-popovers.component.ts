import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-tooltip-popovers',
  templateUrl: './basic-tooltip-popovers.component.html',
  styleUrls: ['./basic-tooltip-popovers.component.scss']
})
export class BasicTooltipPopoversComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
