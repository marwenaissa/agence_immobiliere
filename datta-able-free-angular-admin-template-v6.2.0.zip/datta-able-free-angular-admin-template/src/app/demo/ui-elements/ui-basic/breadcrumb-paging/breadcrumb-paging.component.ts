import { Component } from '@angular/core';

@Component({
  selector: 'app-breadcrumb-paging',
  imports: [],
  templateUrl: './breadcrumb-paging.component.html',
  styleUrls: ['./breadcrumb-paging.component.scss']
})
export class BreadcrumbPagingComponent {}
